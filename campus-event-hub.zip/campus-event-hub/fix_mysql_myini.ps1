# Run this in the Administrator PowerShell window.
# Fixes the my.ini setting that crashes MySQL 8.0.0-dmr, then starts the service.

$ini = "C:\ProgramData\MySQL\MySQL Server 8.0\my.ini"

Write-Host "Reading my.ini..." -ForegroundColor Cyan
$lines = Get-Content $ini

$fixed = @()
foreach ($line in $lines) {
    if ($line -eq "internal_tmp_mem_storage_engine=TempTable") {
        $fixed += "# internal_tmp_mem_storage_engine=TempTable"
        Write-Host "Commented out: $line" -ForegroundColor Green
    } else {
        $fixed += $line
    }
}

[System.IO.File]::WriteAllLines($ini, $fixed)
Write-Host "my.ini saved successfully." -ForegroundColor Green

Write-Host "Starting MySQL80 service..." -ForegroundColor Cyan
Start-Service MySQL80
Start-Sleep -Seconds 4

$status = (Get-Service MySQL80).Status
if ($status -eq "Running") {
    Write-Host "MySQL80 is RUNNING!" -ForegroundColor Green
} else {
    Write-Host "MySQL80 status: $status" -ForegroundColor Red
    Write-Host "Check Windows Event Viewer > Application logs for details." -ForegroundColor Yellow
}
