# Restore/Import database/backup.sql into local MySQL
param(
    [string]$User = "root",
    [string]$Password = "Sanjay@096",
    [string]$SqlFile = "$PSScriptRoot\backup.sql"
)

$mysqlExe = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
if (-not (Test-Path $mysqlExe)) {
    $mysqlExe = "mysql"
}

if (-not (Test-Path $SqlFile)) {
    Write-Host "Error: File '$SqlFile' does not exist." -ForegroundColor Red
    exit 1
}

Write-Host "Importing '$SqlFile' into MySQL..." -ForegroundColor Cyan
Get-Content $SqlFile | & $mysqlExe -u $User -p"$Password"

if ($LASTEXITCODE -eq 0) {
    Write-Host "Database imported successfully!" -ForegroundColor Green
} else {
    Write-Host "Import failed with exit code $LASTEXITCODE" -ForegroundColor Red
}
