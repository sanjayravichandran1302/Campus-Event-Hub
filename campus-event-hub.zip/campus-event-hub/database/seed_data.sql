-- ============================================================================
-- Campus Event Hub - Seed Data
-- ============================================================================

USE `campus_event_hub`;

-- ----------------------------------------------------------------------------
-- Authorized Administrators:
--   1. sanjayravichandran1302@gmail.com (Admin)
--   2. ishwaryayogaraj557@gmail.com     (Admin)
-- Default passwords:
--   sanjayravichandran1302@gmail.com -> admin123
-- ----------------------------------------------------------------------------
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `department`, `created_at`) VALUES
(3, 'Ishwarya', 'ishwaryayogaraj557@gmail.com', '$2a$10$Mq80NT2z/37Q0mThNpsMYuckIWlgi9s0U6Ca9IMPVxBWV8acaZAxm', 'ADMIN', 'Administration', NOW(6)),
(4, 'Sanjay Kumar', 'sanjayravichandran1302@gmail.com', '$2a$10$pm1SGRgPwwaYDMl2AWQOKu0AGkYx4rZhhVrwwWMaHvOipyJ5cG/z2', 'ADMIN', 'Administration', NOW(6))
ON DUPLICATE KEY UPDATE `role` = VALUES(`role`), `name` = VALUES(`name`);
