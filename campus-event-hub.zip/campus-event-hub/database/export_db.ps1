# Export live campus_event_hub MySQL database to database/backup.sql
param(
    [string]$User = "root",
    [string]$Password = "Sanjay@096",
    [string]$Database = "campus_event_hub",
    [string]$OutputFile = "$PSScriptRoot\backup.sql"
)

$mysqlDump = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqldump.exe"
if (-not (Test-Path $mysqlDump)) {
    $mysqlDump = "mysqldump"
}

Write-Host "Exporting MySQL database '$Database' to '$OutputFile'..." -ForegroundColor Cyan
& $mysqlDump -u $User -p"$Password" --databases $Database --result-file="$OutputFile"

if ($LASTEXITCODE -eq 0) {
    Write-Host "Export completed successfully!" -ForegroundColor Green
} else {
    Write-Host "Export failed with exit code $LASTEXITCODE" -ForegroundColor Red
}
