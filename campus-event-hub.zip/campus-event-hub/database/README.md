# Campus Event Hub - Database Documentation

This directory contains the database scripts, schemas, and backup files for **Campus Event Hub**.

---

## Files Overview

| File | Description |
|---|---|
| [`schema.sql`](file:///c:/Users/Sanjaykumar/Downloads/campus-event-hub/database/schema.sql) | Clean DDL defining database creation, tables (`users`, `events`, `registrations`, `certificates`), keys, indexes, and constraints. |
| [`seed_data.sql`](file:///c:/Users/Sanjaykumar/Downloads/campus-event-hub/database/seed_data.sql) | Initial seed records for authorized Administrator accounts. Mock events have been removed so only admin-created events are stored. |
| [`backup.sql`](file:///c:/Users/Sanjaykumar/Downloads/campus-event-hub/database/backup.sql) | Full `mysqldump` snapshot of the live database including table definitions and all current data. |
| [`export_db.ps1`](file:///c:/Users/Sanjaykumar/Downloads/campus-event-hub/database/export_db.ps1) | PowerShell script to quickly dump the live MySQL database into `backup.sql`. |
| [`import_db.ps1`](file:///c:/Users/Sanjaykumar/Downloads/campus-event-hub/database/import_db.ps1) | PowerShell script to restore or re-import `backup.sql` into local MySQL. |

---

## Database Architecture

* **Database Engine**: MySQL 8.0+ / InnoDB
* **Character Set**: `utf8mb4`
* **Collation**: `utf8mb4_unicode_ci`

### Tables & Relationships

1. **`users`**
   * Stores user credentials, roles (`STUDENT`, `ADMIN`), department, and registration timestamp.
   * Authentication uses BCrypt-hashed passwords.

2. **`events`**
   * Stores campus event title, description, category, date, time, venue, organizer, capacity, and status (`OPEN`, `CLOSED`, `COMPLETED`).

3. **`registrations`**
   * Maps many-to-one between `users` and `events`.
   * Includes `qr_token` (unique 64-char token for QR-code check-ins) and `attended` flag.

4. **`certificates`**
   * Generated upon event completion/attendance.
   * Maps `user_id` and `event_id` with unique `certificate_number` and issue date.

---

## Authorized Administrator Accounts

| Email | Password | Role | Department |
|---|---|---|---|
| `sanjayravichandran1302@gmail.com` | `admin123` | `ADMIN` | Administration |
| `ishwaryayogaraj557@gmail.com` | `admin123` | `ADMIN` | Administration |

*Note: Students create their own accounts via the registration page.*

---

## How to Backup & Restore

### Backup the live database:
```powershell
.\database\export_db.ps1
```

### Restore / Re-seed from backup:
```powershell
.\database\import_db.ps1
```
