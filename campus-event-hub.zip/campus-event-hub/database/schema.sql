-- ============================================================================
-- Campus Event Hub - Database Schema
-- Database: campus_event_hub
-- RDBMS: MySQL 8.0+
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `campus_event_hub` 
  DEFAULT CHARACTER SET utf8mb4 
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `campus_event_hub`;

-- ----------------------------------------------------------------------------
-- Table: users
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) NOT NULL COMMENT 'STUDENT, ADMIN',
  `department` VARCHAR(100) DEFAULT NULL,
  `created_at` DATETIME(6) DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- Table: events
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `events` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(150) NOT NULL,
  `description` VARCHAR(2000) DEFAULT NULL,
  `category` VARCHAR(60) NOT NULL,
  `date` DATE NOT NULL,
  `time` TIME(6) NOT NULL,
  `venue` VARCHAR(150) NOT NULL,
  `organizer` VARCHAR(100) NOT NULL,
  `capacity` INT NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'OPEN' COMMENT 'OPEN, CLOSED, COMPLETED',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- Table: registrations
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `registrations` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT NOT NULL,
  `event_id` BIGINT NOT NULL,
  `qr_token` VARCHAR(64) NOT NULL,
  `attended` BIT(1) NOT NULL DEFAULT b'0',
  `registered_at` DATETIME(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_registration_user_event` (`user_id`, `event_id`),
  UNIQUE KEY `uk_registration_qr_token` (`qr_token`),
  KEY `idx_registrations_event` (`event_id`),
  CONSTRAINT `fk_registrations_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_registrations_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- Table: certificates
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `certificates` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT NOT NULL,
  `event_id` BIGINT NOT NULL,
  `certificate_number` VARCHAR(20) NOT NULL,
  `issued_date` DATE NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_certificate_user_event` (`user_id`, `event_id`),
  UNIQUE KEY `uk_certificate_number` (`certificate_number`),
  KEY `idx_certificates_event` (`event_id`),
  CONSTRAINT `fk_certificates_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_certificates_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
