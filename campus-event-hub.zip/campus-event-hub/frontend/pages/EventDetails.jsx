import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { QRCodeCanvas } from 'qrcode.react';
import { getEventById } from '../services/eventService';
import { getMyRegistrations, registerForEvent } from '../services/registrationService';
import { getErrorMessage } from '../services/api';
import Loading from '../components/Loading';
import useAuth from '../hooks/useAuth';

function EventDetails() {
  const { id } = useParams();
  const { user } = useAuth();

  const [event, setEvent] = useState(null);
  const [registration, setRegistration] = useState(null);
  const [loading, setLoading] = useState(true);
  const [registering, setRegistering] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        setEvent(await getEventById(id));
        if (user?.role === 'STUDENT') {
          const myRegistrations = await getMyRegistrations();
          const existing = myRegistrations.find((reg) => reg.event?.id === Number(id));
          if (existing) setRegistration(existing);
        }
      } catch (err) {
        setError(getErrorMessage(err, 'Event not found'));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id, user]);

  const handleRegister = async () => {
    setRegistering(true);
    setError('');
    setSuccess('');
    try {
      const newRegistration = await registerForEvent(id);
      setRegistration(newRegistration);
      setSuccess('🎉 Registration successful! Show the QR code below at the event venue.');
    } catch (err) {
      setError(getErrorMessage(err, 'Could not register for this event'));
    } finally {
      setRegistering(false);
    }
  };

  if (loading) {
    return <div className="container py-5"><Loading message="Loading event details..." /></div>;
  }

  if (!event) {
    return (
      <div className="container py-5">
        <div className="empty-state">
          <div className="empty-icon">😕</div>
          <p className="mt-2">{error || 'Event not found.'}</p>
          <Link to="/events" className="btn ceh-btn btn-sm mt-3">← Back to Events</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-5">
      <div className="row g-4">
        {/* Left: event information */}
        <div className="col-lg-7">
          <div className="event-details-card">
            <div className="d-flex flex-wrap gap-2 mb-3">
              <span className="category-badge">{event.category}</span>
              <span className={`status-badge status-${(event.status || 'open').toLowerCase()}`}>{event.status}</span>
            </div>

            <h2 className="fw-bold">{event.title}</h2>
            <p className="text-muted mt-3" style={{ whiteSpace: 'pre-line' }}>
              {event.description || 'No description provided.'}
            </p>

            <div className="detail-meta mt-4">
              <div className="detail-meta-item"><div className="label">Date</div><div className="value">📅 {event.date}</div></div>
              <div className="detail-meta-item"><div className="label">Time</div><div className="value">⏰ {String(event.time).slice(0, 5)}</div></div>
              <div className="detail-meta-item"><div className="label">Venue</div><div className="value">📍 {event.venue}</div></div>
              <div className="detail-meta-item"><div className="label">Organizer</div><div className="value">🏛️ {event.organizer}</div></div>
              <div className="detail-meta-item"><div className="label">Capacity</div><div className="value">🎟️ {event.capacity} seats</div></div>
              <div className="detail-meta-item"><div className="label">Category</div><div className="value">🏷️ {event.category}</div></div>
            </div>
          </div>
        </div>

        {/* Right: registration / QR pass */}
        <div className="col-lg-5">
          <div className="event-details-card">
            <h5 className="fw-semibold mb-3">Registration</h5>

            {error && <div className="alert alert-danger py-2 small">{error}</div>}
            {success && <div className="alert alert-success py-2 small">{success}</div>}

            {!user && (
              <div className="text-center py-3">
                <p className="text-muted small">Login as a student to register for this event.</p>
                <Link to="/login" className="btn ceh-btn">Login to Register</Link>
              </div>
            )}

            {user?.role === 'ADMIN' && (
              <div className="text-center py-3">
                <p className="text-muted small">You are logged in as an admin. Manage this event from the admin dashboard.</p>
                <Link to="/admin" className="btn ceh-btn-outline btn-sm">Go to Dashboard</Link>
              </div>
            )}

            {user?.role === 'STUDENT' && registration && (
              <div>
                <div className="alert alert-success py-2 small">✅ You are registered for this event!</div>
                <div className="qr-box mt-3">
                  <p className="small text-muted mb-2">Your QR pass – show this at the venue</p>
                  <QRCodeCanvas value={registration.qrToken} size={160} level="M" />
                  <div className="mt-2"><span className="qr-token">{registration.qrToken}</span></div>
                </div>
                <div className="text-center mt-3">
                  {registration.attended ? (
                    <>
                      <span className="badge status-badge status-open">✔ Attendance marked</span>
                      <div className="mt-3">
                        <Link to="/certificates" className="btn ceh-btn-success btn-sm">📜 View Certificate</Link>
                      </div>
                    </>
                  ) : (
                    <span className="text-muted small">⏳ Attendance pending – show your QR at the venue</span>
                  )}
                </div>
              </div>
            )}

            {user?.role === 'STUDENT' && !registration && (
              <div className="text-center py-3">
                {event.status === 'OPEN' ? (
                  <>
                    <p className="text-muted small">Click below to reserve your seat and get your QR pass.</p>
                    <button className="btn ceh-btn" onClick={handleRegister} disabled={registering}>
                      {registering ? 'Registering…' : 'Register for this Event'}
                    </button>
                  </>
                ) : (
                  <p className="text-muted small mb-0">🚫 Registrations are <strong>{event.status}</strong> for this event.</p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default EventDetails;