import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { QRCodeCanvas } from 'qrcode.react';
import { getMyRegistrations } from '../services/registrationService';
import { getErrorMessage } from '../services/api';
import Loading from '../components/Loading';

function MyEvents() {
  const [registrations, setRegistrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        setRegistrations(await getMyRegistrations());
      } catch (err) {
        setError(getErrorMessage(err, 'Failed to load your events'));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const copyToken = async (token) => {
    try {
      await navigator.clipboard.writeText(token);
      setCopied(token);
      setTimeout(() => setCopied(''), 2000);
    } catch { /* clipboard unavailable */ }
  };

  if (loading) {
    return <div className="container py-5"><Loading message="Loading your events..." /></div>;
  }

  return (
    <div className="container py-5">
      <div className="section-header">
        <h2 className="section-title">My Events</h2>
        <p className="section-subtitle">Your registrations, QR passes and attendance status.</p>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      {registrations.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🎟️</div>
          <p className="mt-2 mb-3">You haven't registered for any events yet.</p>
          <Link to="/events" className="btn ceh-btn btn-sm">Browse Events</Link>
        </div>
      ) : (
        <div className="row g-4">
          {registrations.map((reg) => (
            <div className="col-md-6 col-xl-4" key={reg.id}>
              <div className="card event-card h-100">
                <div className="card-body d-flex flex-column">
                  <div className="d-flex justify-content-between align-items-start mb-2">
                    <span className="category-badge">{reg.event.category}</span>
                    <span className={`status-badge ${reg.attended ? 'status-open' : 'status-completed'}`}>
                      {reg.attended ? 'Attended ✔' : 'Pending'}
                    </span>
                  </div>

                  <h5 className="event-card-title">{reg.event.title}</h5>
                  <ul className="event-meta mb-3">
                    <li>📅 {reg.event.date} at {String(reg.event.time).slice(0, 5)}</li>
                    <li>📍 {reg.event.venue}</li>
                    <li>🏛️ {reg.event.organizer}</li>
                  </ul>

                  <div className="qr-box mt-auto">
                    <QRCodeCanvas value={reg.qrToken} size={120} level="M" />
                    <div className="mt-2 d-flex justify-content-center align-items-center gap-2 flex-wrap">
                      <span className="qr-token qr-token-sm">{reg.qrToken}</span>
                      <button className="btn btn-sm btn-outline-secondary py-0 px-2" onClick={() => copyToken(reg.qrToken)}>
                        {copied === reg.qrToken ? 'Copied!' : 'Copy'}
                      </button>
                    </div>
                  </div>

                  {reg.attended && (
                    <Link to="/certificates" className="btn ceh-btn-success btn-sm mt-3">
                      📜 View Certificate
                    </Link>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default MyEvents;