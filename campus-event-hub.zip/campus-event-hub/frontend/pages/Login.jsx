import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth';
import { getErrorMessage } from '../services/api';

const AUTHORIZED_ADMINS = [
  { name: 'Sanjay Kumar', email: 'sanjayravichandran1302@gmail.com' },
  { name: 'Ishwarya Yogaraj', email: 'ishwaryayogaraj557@gmail.com' },
];

function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();

  // Role tab: 'STUDENT' or 'ADMIN'
  const [selectedRole, setSelectedRole] = useState('STUDENT');
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // If already logged in, redirect according to role
  if (user) {
    return <Navigate to={user.role === 'ADMIN' ? '/admin' : '/dashboard'} replace />;
  }

  const handleRoleChange = (role) => {
    setSelectedRole(role);
    setError('');
    // Optionally pre-fill demo email for convenience
    if (role === 'ADMIN') {
      setForm((prev) => ({ ...prev, email: AUTHORIZED_ADMINS[0].email, password: '' }));
    } else {
      setForm((prev) => ({ ...prev, email: '', password: '' }));
    }
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSelectAdmin = (adminEmail) => {
    setForm({ ...form, email: adminEmail });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const emailTrimmed = form.email.trim().toLowerCase();

    if (!emailTrimmed || !form.password) {
      setError('Please enter your email and password.');
      return;
    }

    // Role-based validation
    if (selectedRole === 'ADMIN') {
      const isAuthorizedAdmin = AUTHORIZED_ADMINS.some(
        (admin) => admin.email.toLowerCase() === emailTrimmed
      );

      if (!isAuthorizedAdmin) {
        setError(
          'Access Denied: Only authorized administrators (' +
          AUTHORIZED_ADMINS.map((a) => a.email).join(', ') +
          ') are permitted to log in as Admin.'
        );
        return;
      }
    }

    setLoading(true);
    try {
      const loggedInUser = await login(emailTrimmed, form.password);

      // Verify role matches expectations
      if (selectedRole === 'ADMIN' && loggedInUser.role !== 'ADMIN') {
        setError('This account does not have administrator privileges.');
        return;
      }

      // Route directly to respective dashboard based on authenticated role
      if (loggedInUser.role === 'ADMIN') {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    } catch (err) {
      setError(getErrorMessage(err, 'Invalid email or password'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        {/* Brand Header */}
        <div className="auth-brand">
          <div className="logo">🎓</div>
          <h3 className="auth-title mt-2">Campus Event Hub</h3>
          <p className="auth-subtitle">Sign in to your account</p>
        </div>

        {/* Role-Based Access Tabs */}
        <div className="auth-role-tabs">
          <button
            type="button"
            className={`auth-role-tab ${selectedRole === 'STUDENT' ? 'active' : ''}`}
            onClick={() => handleRoleChange('STUDENT')}
          >
            🎓 Student Portal
          </button>
          <button
            type="button"
            className={`auth-role-tab admin-tab ${selectedRole === 'ADMIN' ? 'active' : ''}`}
            onClick={() => handleRoleChange('ADMIN')}
          >
            🛡️ Admin Portal
          </button>
        </div>

        {/* Role-specific Notice Banner */}
        {selectedRole === 'ADMIN' ? (
          <div className="admin-notice-box">
            <div className="d-flex align-items-center gap-2 mb-1">
              <span className="badge bg-purple text-white" style={{ background: '#7c3aed' }}>
                ADMIN ACCESS ONLY
              </span>
              <small className="fw-semibold text-secondary">Authorized IDs</small>
            </div>
            <p className="small text-muted mb-2" style={{ fontSize: '0.8rem' }}>
              Only two designated administrators have access to this portal:
            </p>
            <div className="d-flex flex-wrap gap-1">
              {AUTHORIZED_ADMINS.map((admin) => (
                <button
                  type="button"
                  key={admin.email}
                  onClick={() => handleSelectAdmin(admin.email)}
                  className={`admin-quick-chip ${form.email === admin.email ? 'selected' : ''}`}
                  title="Click to select this admin"
                >
                  👤 {admin.name} ({admin.email.split('@')[0]})
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="alert alert-light border small py-2 mb-3 text-muted">
            <span className="fw-semibold text-dark">🎓 Student Access:</span> Browse upcoming events, get your unique QR pass, and collect certificates.
          </div>
        )}

        {/* Error message */}
        {error && <div className="alert alert-danger py-2 small">{error}</div>}

        {/* Login Form */}
        <form onSubmit={handleSubmit} noValidate>
          <div className="mb-3">
            <label className="form-label small fw-semibold">
              {selectedRole === 'ADMIN' ? 'Admin Google ID / Email' : 'Student Email'}
            </label>
            <input
              type="email"
              name="email"
              className="form-control auth-input"
              placeholder={selectedRole === 'ADMIN' ? 'admin@gmail.com' : 'you@campus.edu'}
              value={form.email}
              onChange={handleChange}
              autoComplete="email"
            />
          </div>

          <div className="mb-4">
            <label className="form-label small fw-semibold">Password</label>
            <div className="password-input-wrapper">
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                className="form-control auth-input"
                placeholder="••••••••"
                value={form.password}
                onChange={handleChange}
                autoComplete="current-password"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="password-toggle-btn"
                tabIndex={-1}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                title={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? (
                  /* Eye-off icon (Slash) */
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
                    <line x1="1" y1="1" x2="23" y2="23" />
                  </svg>
                ) : (
                  /* Eye icon */
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                )}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className={`btn ceh-btn w-100 ${selectedRole === 'ADMIN' ? 'btn-dark' : ''}`}
            disabled={loading}
          >
            {loading ? 'Authenticating…' : selectedRole === 'ADMIN' ? '🛡️ Login as Admin' : '🎓 Login as Student'}
          </button>
        </form>

        {/* Authorized Admin Quick Reference (Admin tab only) */}
        {selectedRole === 'ADMIN' && (
          <div className="alert alert-light border small py-2 mt-4 mb-0 text-muted">
            <strong>Authorized Administrators:</strong><br />
            • <code>sanjayravichandran1302@gmail.com</code><br />
            • <code>ishwaryayogaraj557@gmail.com</code>
          </div>
        )}

        {/* Footer Link */}
        <p className="text-center text-muted small mt-3 mb-0">
          {selectedRole === 'ADMIN' ? (
            <span>Need a student account? <Link to="/register" className="fw-semibold">Register here</Link></span>
          ) : (
            <span>New student? <Link to="/register" className="fw-semibold">Create an account</Link></span>
          )}
        </p>
      </div>
    </div>
  );
}

export default Login;