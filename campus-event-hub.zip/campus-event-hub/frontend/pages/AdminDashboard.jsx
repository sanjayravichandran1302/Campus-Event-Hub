import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { deleteEvent, getAllEvents } from '../services/eventService';
import {
  generateCertificate,
  getAllCertificates,
  getAllRegistrations,
  getEventParticipants,
} from '../services/registrationService';
import { getErrorMessage } from '../services/api';
import Loading from '../components/Loading';

function AdminDashboard() {
  const navigate = useNavigate();
  const [events, setEvents] = useState([]);
  const [registrations, setRegistrations] = useState([]);
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [participantsLoading, setParticipantsLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const loadData = async () => {
    try {
      const [eventList, registrationList, certificateList] = await Promise.all([
        getAllEvents(),
        getAllRegistrations(),
        getAllCertificates(),
      ]);
      setEvents(eventList);
      setRegistrations(registrationList);
      setCertificates(certificateList);
    } catch (err) {
      setError(getErrorMessage(err, 'Failed to load dashboard data'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  const countForEvent = (eventId) => registrations.filter((r) => r.event?.id === eventId).length;

  const hasCertificate = (registration) =>
    certificates.some(
      (cert) => cert.user?.id === registration.user?.id && cert.event?.id === registration.event?.id
    );

  const handleDelete = async (event) => {
    if (!window.confirm(`Delete "${event.title}"? This action cannot be undone.`)) return;
    setError(''); setMessage('');
    try {
      await deleteEvent(event.id);
      setMessage(`Event "${event.title}" was deleted successfully.`);
      if (selectedEvent?.id === event.id) setSelectedEvent(null);
      await loadData();
    } catch (err) {
      setError(getErrorMessage(err, 'Could not delete the event'));
    }
  };

  const openParticipants = async (event) => {
    setSelectedEvent(event);
    setParticipantsLoading(true);
    try {
      setParticipants(await getEventParticipants(event.id));
    } catch (err) {
      setError(getErrorMessage(err, 'Could not load participants'));
    } finally {
      setParticipantsLoading(false);
    }
  };

  const handleGenerateCertificate = async (registration) => {
    setError(''); setMessage('');
    try {
      await generateCertificate(registration.id);
      setMessage(`Certificate generated for ${registration.user.name}.`);
      await loadData();
      if (selectedEvent) await openParticipants(selectedEvent);
    } catch (err) {
      setError(getErrorMessage(err, 'Could not generate certificate'));
    }
  };

  if (loading) {
    return <div className="container py-5"><Loading message="Loading admin dashboard..." /></div>;
  }

  const stats = [
    { icon: '📅', label: 'Total Events', value: events.length, bg: 'bg-stat-primary' },
    { icon: '🟢', label: 'Open Events', value: events.filter((e) => e.status === 'OPEN').length, bg: 'bg-stat-success' },
    { icon: '🎟️', label: 'Total Registrations', value: registrations.length, bg: 'bg-stat-primary' },
    { icon: '✔️', label: 'Attendance Marked', value: registrations.filter((r) => r.attended).length, bg: 'bg-stat-success' },
    { icon: '📜', label: 'Certificates Issued', value: certificates.length, bg: 'bg-stat-warning' },
  ];

  return (
    <div className="container py-5">
      <div className="d-flex flex-wrap justify-content-between align-items-start gap-3 section-header">
        <div>
          <h2 className="section-title">Admin Dashboard</h2>
          <p className="section-subtitle">Manage events, participants, attendance and certificates.</p>
        </div>
        <div className="d-flex gap-2">
          <Link to="/admin/events/new" className="btn ceh-btn btn-sm">＋ Create Event</Link>
          <Link to="/admin/attendance" className="btn ceh-btn-outline btn-sm">📷 Scan Attendance</Link>
        </div>
      </div>

      {message && <div className="alert alert-success py-2">{message}</div>}
      {error && <div className="alert alert-danger py-2">{error}</div>}

      {/* Statistics */}
      <div className="row g-3 mb-4">
        {stats.map((stat) => (
          <div className="col-6 col-md-4 col-xl" key={stat.label}>
            <div className="stat-card">
              <div className={`stat-icon ${stat.bg}`}>{stat.icon}</div>
              <div>
                <div className="stat-value">{stat.value}</div>
                <div className="stat-label">{stat.label}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Events table */}
      <div className="dashboard-table table-responsive">
        <table className="table align-middle">
          <thead>
            <tr>
              <th>Title</th><th>Category</th><th>Date</th><th>Status</th><th>Registered</th>
              <th className="text-end">Actions</th>
            </tr>
          </thead>
          <tbody>
            {events.length === 0 ? (
              <tr>
                <td colSpan="6" className="text-center text-muted py-4">
                  No events yet. Create your first event!
                </td>
              </tr>
            ) : (
              events.map((event) => (
                <tr key={event.id}>
                  <td className="fw-semibold">{event.title}</td>
                  <td><span className="category-badge">{event.category}</span></td>
                  <td>{event.date}</td>
                  <td><span className={`status-badge status-${event.status.toLowerCase()}`}>{event.status}</span></td>
                  <td>{countForEvent(event.id)} / {event.capacity}</td>
                  <td className="text-end text-nowrap">
                    <button className="table-action-btn" title="Edit"
                      onClick={() => navigate(`/admin/events/${event.id}/edit`)}>✏️</button>
                    <button className="table-action-btn" title="Participants"
                      onClick={() => openParticipants(event)}>👥</button>
                    <button className="table-action-btn" title="Delete"
                      onClick={() => handleDelete(event)}>🗑️</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Participants panel */}
      {selectedEvent && (
        <div className="participants-panel">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h5 className="fw-semibold mb-0">👥 Participants – {selectedEvent.title}</h5>
            <button className="btn btn-sm btn-outline-secondary" onClick={() => setSelectedEvent(null)}>Close</button>
          </div>

          {participantsLoading ? (
            <div className="text-center py-4">
              <div className="spinner-border ceh-spinner" style={{ width: '2rem', height: '2rem' }} />
            </div>
          ) : participants.length === 0 ? (
            <p className="text-muted mb-0">No students have registered for this event yet.</p>
          ) : (
            <div className="table-responsive">
              <table className="table align-middle">
                <thead>
                  <tr><th>#</th><th>Student</th><th>Email</th><th>QR Token</th><th>Attendance</th><th>Certificate</th></tr>
                </thead>
                <tbody>
                  {participants.map((reg, index) => (
                    <tr key={reg.id}>
                      <td>{index + 1}</td>
                      <td className="fw-semibold">{reg.user.name}</td>
                      <td className="text-muted">{reg.user.email}</td>
                      <td><span className="qr-token qr-token-sm">{reg.qrToken}</span></td>
                      <td>
                        <span className={`status-badge ${reg.attended ? 'status-open' : 'status-completed'}`}>
                          {reg.attended ? 'Attended' : 'Pending'}
                        </span>
                      </td>
                      <td>
                        {!reg.attended ? (
                          <span className="text-muted small">—</span>
                        ) : hasCertificate(reg) ? (
                          <span className="status-badge status-open">Issued ✔</span>
                        ) : (
                          <button className="btn ceh-btn-success btn-sm py-1"
                            onClick={() => handleGenerateCertificate(reg)}>
                            📜 Generate
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;