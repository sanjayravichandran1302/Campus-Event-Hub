import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import EventForm from '../components/EventForm';
import Loading from '../components/Loading';
import { createEvent, getEventById, updateEvent } from '../services/eventService';

function CreateEvent({ edit = false }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [initialValues, setInitialValues] = useState(null);
  const [loading, setLoading] = useState(edit);

  useEffect(() => {
    if (!edit) return;
    const load = async () => {
      try {
        setInitialValues(await getEventById(id));
      } catch {
        setInitialValues({});
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [edit, id]);

  const handleSubmit = async (data) => {
    if (edit) {
      await updateEvent(id, data);
    } else {
      await createEvent(data);
    }
    navigate('/admin');
  };

  if (loading) {
    return <div className="container py-5"><Loading message="Loading event..." /></div>;
  }

  return (
    <div className="container py-5" style={{ maxWidth: 860 }}>
      <div className="section-header">
        <h2 className="section-title">{edit ? '✏️ Edit Event' : '➕ Create New Event'}</h2>
        <p className="section-subtitle">
          {edit ? 'Update the event details below.' : 'Fill in the details to publish a new campus event.'}
        </p>
      </div>
      <div className="event-details-card">
        <EventForm
          initialValues={initialValues || {}}
          onSubmit={handleSubmit}
          submitLabel={edit ? 'Update Event' : 'Create Event'}
          onCancel={() => navigate('/admin')}
        />
      </div>
    </div>
  );
}

export default CreateEvent;