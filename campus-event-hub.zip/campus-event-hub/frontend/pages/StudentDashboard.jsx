import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getMyCertificates, getMyRegistrations } from '../services/registrationService';
import Loading from '../components/Loading';
import useAuth from '../hooks/useAuth';

function StudentDashboard() {
  const { user } = useAuth();
  const [registrations, setRegistrations] = useState([]);
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [regs, certs] = await Promise.all([getMyRegistrations(), getMyCertificates()]);
        setRegistrations(regs);
        setCertificates(certs);
      } catch { /* axios interceptor handles auth errors */ }
      finally { setLoading(false); }
    };
    load();
  }, []);

  if (loading) {
    return <div className="container py-5"><Loading message="Loading your dashboard..." /></div>;
  }

  const today = new Date().toISOString().slice(0, 10);
  const attendedCount = registrations.filter((r) => r.attended).length;
  const upcoming = registrations
    .filter((r) => r.event.date >= today && r.event.status === 'OPEN')
    .sort((a, b) => a.event.date.localeCompare(b.event.date))[0];

  const stats = [
    { icon: '🎟️', label: 'Events Registered', value: registrations.length, bg: 'bg-stat-primary' },
    { icon: '✔️', label: 'Events Attended', value: attendedCount, bg: 'bg-stat-success' },
    { icon: '📜', label: 'Certificates Earned', value: certificates.length, bg: 'bg-stat-warning' },
  ];

  return (
    <div className="container py-5">
      <div className="section-header">
        <h2 className="section-title">Hi {user?.name?.split(' ')[0]} 👋</h2>
        <p className="section-subtitle">Here's a quick look at your campus event activity.</p>
      </div>

      <div className="row g-4 mb-4">
        {stats.map((stat) => (
          <div className="col-md-4" key={stat.label}>
            <div className="stat-card">
              <div className={`stat-icon ${stat.bg}`}>{stat.icon}</div>
              <div>
                <div className="stat-value">{stat.value}</div>
                <div className="stat-label">{stat.label}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="row g-4">
        <div className="col-lg-7">
          <div className="dashboard-panel">
            <h5 className="fw-semibold">📌 Your Next Event</h5>
            {upcoming ? (
              <div>
                <h4 className="fw-bold mt-3">{upcoming.event.title}</h4>
                <p className="text-muted mb-1">
                  📅 {upcoming.event.date} · ⏰ {String(upcoming.event.time).slice(0, 5)}
                </p>
                <p className="text-muted mb-0">📍 {upcoming.event.venue}</p>
                <div className="d-flex gap-2 mt-3">
                  <Link to="/my-events" className="btn ceh-btn btn-sm">Show QR Pass</Link>
                  <Link to={`/events/${upcoming.event.id}`} className="btn ceh-btn-outline btn-sm">Event Details</Link>
                </div>
              </div>
            ) : (
              <div className="empty-state mt-3">
                <div className="empty-icon">🗓️</div>
                <p className="mt-2 mb-3">No upcoming events registered.</p>
                <Link to="/events" className="btn ceh-btn btn-sm">Browse Events</Link>
              </div>
            )}
          </div>
        </div>

        <div className="col-lg-5">
          <div className="dashboard-panel h-100">
            <h5 className="fw-semibold">⚡ Quick Actions</h5>
            <div className="d-grid gap-2 mt-3">
              <Link to="/events" className="btn ceh-btn">🔍 Browse &amp; Register for Events</Link>
              <Link to="/my-events" className="btn ceh-btn-outline">🎟️ My Events &amp; QR Passes</Link>
              <Link to="/certificates" className="btn ceh-btn-outline">📜 My Certificates</Link>
              <Link to="/profile" className="btn ceh-btn-outline">👤 Manage Profile</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default StudentDashboard;