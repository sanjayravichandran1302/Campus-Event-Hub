import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { markAttendance } from '../services/registrationService';
import { getErrorMessage } from '../services/api';

function Attendance() {
  const scannerRef = useRef(null);
  const [scanning, setScanning] = useState(false);
  const [token, setToken] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const submitToken = async (qrToken) => {
    const cleanToken = (qrToken || '').trim();
    if (!cleanToken) { setError('Please provide a QR token.'); return; }
    setLoading(true);
    setError('');
    setResult(null);
    try {
      setResult(await markAttendance(cleanToken));
    } catch (err) {
      setError(getErrorMessage(err, 'Failed to mark attendance'));
    } finally {
      setLoading(false);
    }
  };

  const stopScanner = async () => {
    if (scannerRef.current) {
      const scanner = scannerRef.current;
      scannerRef.current = null;
      try {
        await scanner.stop();
        scanner.clear();
      } catch { /* already stopped */ }
      setScanning(false);
    }
  };

  const startScanner = async () => {
    setError('');
    try {
      const scanner = new Html5Qrcode('qr-reader');
      scannerRef.current = scanner;
      await scanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 240, height: 240 } },
        async (decodedText) => {
          await stopScanner();           // stop after the first successful scan
          submitToken(decodedText);
        },
        () => { /* ignore per-frame decode errors */ }
      );
      setScanning(true);
    } catch {
      setError('Unable to start the camera. Please use manual token entry instead.');
    }
  };

  // Stop the camera when leaving the page
  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        scannerRef.current.stop().catch(() => {});
        scannerRef.current = null;
      }
    };
  }, []);

  return (
    <div className="container py-5">
      <div className="section-header">
        <h2 className="section-title">📷 QR Attendance Scanner</h2>
        <p className="section-subtitle">Scan a student's QR pass or enter the token manually to mark attendance.</p>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}
      {result && <div className="alert alert-success"><strong>✔ {result.message}</strong></div>}

      <div className="row g-4">
        {/* Camera scanner */}
        <div className="col-lg-7">
          <div className="dashboard-panel">
            <h5 className="fw-semibold">Camera Scanner</h5>
            <p className="text-muted small">
              Point the camera at the student's QR code. Scanning stops automatically after a successful scan.
            </p>
            {!scanning ? (
              <button className="btn ceh-btn" onClick={startScanner}>▶ Start Camera</button>
            ) : (
              <button className="btn ceh-btn-danger" onClick={stopScanner}>■ Stop Camera</button>
            )}
            <div id="qr-reader" className="mt-3" />
          </div>
        </div>

        {/* Manual entry */}
        <div className="col-lg-5">
          <div className="dashboard-panel">
            <h5 className="fw-semibold">Manual Token Entry</h5>
            <p className="text-muted small">No camera? Type or paste the QR token shown on the student's pass.</p>
            <form className="d-flex gap-2" onSubmit={(e) => { e.preventDefault(); submitToken(token); }}>
              <input
                className="form-control search-input"
                placeholder="e.g. 9F86D081884C7D65…"
                value={token}
                onChange={(e) => setToken(e.target.value)}
              />
              <button className="btn ceh-btn" type="submit" disabled={loading}>
                {loading ? '…' : 'Mark'}
              </button>
            </form>

            {result && (
              <div className="attendance-result mt-4">
                <div className="detail-meta-item">
                  <div className="label">Student</div>
                  <div className="value">{result.registration.user.name}</div>
                </div>
                <div className="detail-meta-item mt-2">
                  <div className="label">Event</div>
                  <div className="value">{result.registration.event.title}</div>
                </div>
                <div className="detail-meta-item mt-2">
                  <div className="label">QR Token</div>
                  <div className="value">{result.registration.qrToken}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Attendance;