import { useEffect, useState } from 'react';
import useAuth from '../hooks/useAuth';
import { getProfile, updateProfile } from '../services/authService';
import { getErrorMessage } from '../services/api';
import Loading from '../components/Loading';

function Profile() {
  const { refreshUser } = useAuth();
  const [form, setForm] = useState({ name: '', department: '' });
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const profile = await getProfile();
        setForm({ name: profile.name || '', department: profile.department || '' });
        setEmail(profile.email || '');
        setRole(profile.role || '');
      } catch (err) {
        setError(getErrorMessage(err, 'Failed to load profile'));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    if (!form.name.trim()) { setError('Name cannot be empty.'); return; }
    setSaving(true);
    try {
      await updateProfile({ name: form.name.trim(), department: form.department.trim() });
      await refreshUser(); // keep navbar + localStorage in sync
      setMessage('Profile updated successfully.');
    } catch (err) {
      setError(getErrorMessage(err, 'Could not update profile'));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="container py-5"><Loading message="Loading profile..." /></div>;
  }

  return (
    <div className="container py-5" style={{ maxWidth: 720 }}>
      <div className="section-header">
        <h2 className="section-title">My Profile</h2>
        <p className="section-subtitle">Manage your account information.</p>
      </div>

      <div className="event-details-card">
        {message && <div className="alert alert-success py-2">{message}</div>}
        {error && <div className="alert alert-danger py-2">{error}</div>}

        <form onSubmit={handleSubmit} noValidate>
          <div className="mb-3">
            <label className="form-label small fw-semibold">Full Name</label>
            <input name="name" className="form-control auth-input" value={form.name} onChange={handleChange} />
          </div>
          <div className="mb-3">
            <label className="form-label small fw-semibold">Department</label>
            <input name="department" className="form-control auth-input" placeholder="e.g. Computer Science"
              value={form.department} onChange={handleChange} />
          </div>
          <div className="mb-4">
            <label className="form-label small fw-semibold">Email (cannot be changed)</label>
            <input className="form-control auth-input" value={email} disabled />
          </div>
          <div className="d-flex justify-content-between align-items-center">
            <span className="badge category-badge">{role}</span>
            <button type="submit" className="btn ceh-btn" disabled={saving}>
              {saving ? 'Saving…' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Profile;