import { useEffect, useState } from 'react';
import { getAllEvents } from '../services/eventService';
import EventCard from '../components/EventCard';
import Loading from '../components/Loading';
import { getErrorMessage } from '../services/api';

const CATEGORIES = ['All', 'Technical', 'Cultural', 'Sports', 'Workshop', 'Seminar', 'Other'];

function Events() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [fetching, setFetching] = useState(false);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');

  useEffect(() => {
    let cancelled = false;

    const fetchEvents = async () => {
      setFetching(true);
      try {
        const data = await getAllEvents(search, category);
        if (!cancelled) { setEvents(data); setError(''); }
      } catch (err) {
        if (!cancelled) setError(getErrorMessage(err, 'Failed to load events.'));
      } finally {
        if (!cancelled) { setLoading(false); setFetching(false); }
      }
    };

    fetchEvents();
    return () => { cancelled = true; };
  }, [search, category]);

  return (
    <div className="container py-5">
      <div className="section-header">
        <h2 className="section-title">All Events</h2>
        <p className="section-subtitle">Search and filter campus events by category.</p>
      </div>

      {/* Search + filters */}
      <div className="events-toolbar mb-4">
        <div className="row g-3 align-items-center">
          <div className="col-lg-5">
            <input
              type="text"
              className="form-control search-input"
              placeholder="🔍 Search events by title..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="col-lg-7">
            <div className="d-flex flex-wrap gap-2">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  className={`filter-btn${category === cat ? ' active' : ''}`}
                  onClick={() => setCategory(cat)}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {fetching && !loading && <p className="text-muted small mb-3">Updating results…</p>}
      {error && <div className="alert alert-danger">{error}</div>}

      {loading ? (
        <Loading message="Loading events..." />
      ) : !error && events.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🗓️</div>
          <p className="mb-0 mt-2">No events match your search. Try different keywords.</p>
        </div>
      ) : (
        <div className="row g-4">
          {events.map((event) => (
            <div className="col-sm-6 col-lg-4" key={event.id}>
              <EventCard event={event} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Events;