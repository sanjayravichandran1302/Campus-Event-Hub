import { useEffect, useState } from 'react';
import Loading from '../components/Loading';
import {
  downloadCertificate,
  generateCertificate,
  getMyCertificates,
  getMyRegistrations,
} from '../services/registrationService';
import { getErrorMessage } from '../services/api';

function Certificate() {
  const [certificates, setCertificates] = useState([]);
  const [registrations, setRegistrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [downloadingId, setDownloadingId] = useState(null);
  const [generatingId, setGeneratingId] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const loadData = async () => {
    try {
      const [certs, regs] = await Promise.all([getMyCertificates(), getMyRegistrations()]);
      setCertificates(certs);
      setRegistrations(regs);
    } catch (err) {
      setError(getErrorMessage(err, 'Failed to load certificates'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  // Attended events that don't have a certificate yet
  const eligible = registrations.filter(
    (reg) => reg.attended && !certificates.some((cert) => cert.event?.id === reg.event?.id)
  );

  const handleGenerate = async (registration) => {
    setError(''); setMessage('');
    setGeneratingId(registration.id);
    try {
      await generateCertificate(registration.id);
      setMessage(`Certificate generated for "${registration.event.title}".`);
      await loadData();
    } catch (err) {
      setError(getErrorMessage(err, 'Could not generate certificate'));
    } finally {
      setGeneratingId(null);
    }
  };

  const handleDownload = async (certificate) => {
    setError('');
    setDownloadingId(certificate.id);
    try {
      const blob = await downloadCertificate(certificate.id);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Certificate-${certificate.certificateNumber}.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError(getErrorMessage(err, 'Could not download the certificate'));
    } finally {
      setDownloadingId(null);
    }
  };

  if (loading) {
    return <div className="container py-5"><Loading message="Loading certificates..." /></div>;
  }

  return (
    <div className="container py-5">
      <div className="section-header">
        <h2 className="section-title">📜 My Certificates</h2>
        <p className="section-subtitle">Certificates you earned by attending campus events.</p>
      </div>

      {message && <div className="alert alert-success py-2">{message}</div>}
      {error && <div className="alert alert-danger py-2">{error}</div>}

      {eligible.length > 0 && (
        <div className="dashboard-panel mb-4">
          <h5 className="fw-semibold">✅ Ready to Generate</h5>
          <p className="text-muted small">You attended these events. Generate your certificate now.</p>
          <div className="d-flex flex-wrap gap-2">
            {eligible.map((reg) => (
              <button
                key={reg.id}
                className="btn ceh-btn-success btn-sm"
                onClick={() => handleGenerate(reg)}
                disabled={generatingId === reg.id}
              >
                {generatingId === reg.id ? 'Generating…' : `📜 ${reg.event.title}`}
              </button>
            ))}
          </div>
        </div>
      )}

      {certificates.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📜</div>
          <p className="mt-2 mb-0">
            {eligible.length === 0
              ? 'No certificates yet. Register for events, attend them and earn certificates!'
              : 'Generate a certificate above to see it here.'}
          </p>
        </div>
      ) : (
        <div className="row g-4">
          {certificates.map((cert) => (
            <div className="col-md-6 col-lg-4" key={cert.id}>
              <div className="card event-card h-100">
                <div className="card-body d-flex flex-column text-center">
                  <div style={{ fontSize: '2.4rem' }}>🏆</div>
                  <h5 className="event-card-title mt-2">{cert.event.title}</h5>
                  <ul className="event-meta text-start">
                    <li>📅 Event date: {cert.event.date}</li>
                    <li>🏷️ Certificate No: <strong>{cert.certificateNumber}</strong></li>
                    <li>🗓️ Issued on: {cert.issuedDate}</li>
                  </ul>
                  <button
                    className="btn ceh-btn mt-auto"
                    onClick={() => handleDownload(cert)}
                    disabled={downloadingId === cert.id}
                  >
                    {downloadingId === cert.id ? 'Preparing PDF…' : '⬇ Download PDF'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Certificate;