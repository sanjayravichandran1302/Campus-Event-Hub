import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getAllEvents } from '../services/eventService';
import EventCard from '../components/EventCard';
import Loading from '../components/Loading';
import useAuth from '../hooks/useAuth';

const FEATURES = [
  { icon: '🔍', title: 'Discover Events', text: 'Browse every workshop, fest and seminar happening on campus in one place.' },
  { icon: '⚡', title: 'One-Click Registration', text: 'Register in seconds and instantly receive a unique QR pass.' },
  { icon: '📷', title: 'QR Attendance', text: 'Admins scan your QR pass at the venue – no more paper attendance sheets.' },
  { icon: '📜', title: 'Digital Certificates', text: 'Attend events and download officially generated participation certificates.' },
];

function Home() {
  const { user } = useAuth();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadEvents = async () => {
      try {
        const all = await getAllEvents();
        setEvents(
          all
            .filter((event) => event.status === 'OPEN')
            .sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))
            .slice(0, 3)
        );
      } catch {
        setEvents([]);
      } finally {
        setLoading(false);
      }
    };
    loadEvents();
  }, []);

  return (
    <>
      {/* Hero */}
      <section className="container mt-4">
        <div className="hero text-center">
          <span className="hero-chip d-inline-block mb-3">🎯 One hub for every campus event</span>
          <h1 className="display-5 fw-bold">Discover. Register.<br />Participate.</h1>
          <p className="lead mx-auto mt-3" style={{ maxWidth: 640, opacity: 0.92 }}>
            Campus Event Hub is your college's central platform to find events, register with a single
            click, get your QR pass, mark attendance and earn certificates.
          </p>
          <div className="d-flex flex-wrap justify-content-center gap-3 mt-4">
            <Link to="/events" className="btn btn-light fw-semibold px-4">Browse Events</Link>
            {!user && <Link to="/register" className="btn hero-outline-btn px-4">Create Student Account</Link>}
            {user?.role === 'ADMIN' && <Link to="/admin" className="btn hero-outline-btn px-4">Open Admin Dashboard</Link>}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container mt-5">
        <div className="section-header text-center">
          <h2 className="section-title">Why Campus Event Hub?</h2>
          <p className="section-subtitle">Everything students and admins need for smooth event management.</p>
        </div>
        <div className="row g-4">
          {FEATURES.map((feature) => (
            <div className="col-md-6 col-lg-3" key={feature.title}>
              <div className="feature-card">
                <div className="feature-icon">{feature.icon}</div>
                <h5 className="mt-3 fw-semibold">{feature.title}</h5>
                <p className="text-muted small mb-0">{feature.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Upcoming events */}
      <section className="container mt-5">
        <div className="d-flex justify-content-between align-items-end section-header">
          <div>
            <h2 className="section-title">Upcoming Events</h2>
            <p className="section-subtitle">Don't miss out – seats are limited.</p>
          </div>
          <Link to="/events" className="btn ceh-btn-outline btn-sm">View All →</Link>
        </div>

        {loading ? (
          <Loading message="Loading upcoming events..." />
        ) : events.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📅</div>
            <p className="mb-0 mt-2">No upcoming events right now. Check back soon!</p>
          </div>
        ) : (
          <div className="row g-4">
            {events.map((event) => (
              <div className="col-md-6 col-lg-4" key={event.id}>
                <EventCard event={event} />
              </div>
            ))}
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="container my-5">
        <div className="cta-banner text-center">
          <h3 className="fw-bold">Ready to join your next campus event?</h3>
          <p className="text-muted">Create your free student account and start collecting certificates today.</p>
          <Link to={user ? '/events' : '/register'} className="btn ceh-btn px-4 mt-2">
            {user ? 'Explore Events' : "Get Started — It's Free"}
          </Link>
        </div>
      </section>
    </>
  );
}

export default Home;