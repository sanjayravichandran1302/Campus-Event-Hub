import { Navigate, Route, Routes } from 'react-router-dom';
import ProtectedRoute from '../components/ProtectedRoute';
import Home from '../pages/Home';
import Login from '../pages/Login';
import Register from '../pages/Register';
import Events from '../pages/Events';
import EventDetails from '../pages/EventDetails';
import MyEvents from '../pages/MyEvents';
import StudentDashboard from '../pages/StudentDashboard';
import AdminDashboard from '../pages/AdminDashboard';
import CreateEvent from '../pages/CreateEvent';
import Profile from '../pages/Profile';
import Attendance from '../pages/Attendance';
import Certificate from '../pages/Certificate';

function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/events" element={<Events />} />
      <Route path="/events/:id" element={<EventDetails />} />

      {/* Student routes */}
      <Route path="/dashboard" element={<ProtectedRoute role="STUDENT"><StudentDashboard /></ProtectedRoute>} />
      <Route path="/my-events" element={<ProtectedRoute role="STUDENT"><MyEvents /></ProtectedRoute>} />
      <Route path="/certificates" element={<ProtectedRoute role="STUDENT"><Certificate /></ProtectedRoute>} />

      {/* Shared route */}
      <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />

      {/* Admin routes */}
      <Route path="/admin" element={<ProtectedRoute role="ADMIN"><AdminDashboard /></ProtectedRoute>} />
      <Route path="/admin/events/new" element={<ProtectedRoute role="ADMIN"><CreateEvent /></ProtectedRoute>} />
      <Route path="/admin/events/:id/edit" element={<ProtectedRoute role="ADMIN"><CreateEvent edit /></ProtectedRoute>} />
      <Route path="/admin/attendance" element={<ProtectedRoute role="ADMIN"><Attendance /></ProtectedRoute>} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default AppRoutes;