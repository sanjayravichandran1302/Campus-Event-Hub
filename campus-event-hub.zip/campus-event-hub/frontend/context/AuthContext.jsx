import { createContext, useCallback, useEffect, useMemo, useState } from 'react';
import * as authService from '../services/authService';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore session from localStorage on first load
  useEffect(() => {
    const storedUser = authService.getStoredUser();
    if (storedUser && authService.getStoredToken()) {
      setUser(storedUser);
    }
    setLoading(false);
  }, []);

  const login = useCallback(async (email, password) => {
    const data = await authService.login(email, password);
    const { token, ...userData } = data;
    authService.saveSession(token, userData);
    setUser(userData);
    return userData;
  }, []);

  const register = useCallback(async (name, email, password, department) => {
    const data = await authService.register(name, email, password, department);
    const { token, ...userData } = data;
    authService.saveSession(token, userData);
    setUser(userData);
    return userData;
  }, []);

  const logout = useCallback(() => {
    authService.logout();
    setUser(null);
  }, []);

  const refreshUser = useCallback(async () => {
    const token = authService.getStoredToken();
    if (!token) return;
    try {
      const profile = await authService.getProfile();
      authService.saveSession(token, profile);
      setUser(profile);
    } catch {
      /* invalid token – the axios interceptor will redirect */
    }
  }, []);

  const value = useMemo(
    () => ({ user, loading, login, register, logout, refreshUser }),
    [user, loading, login, register, logout, refreshUser]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}