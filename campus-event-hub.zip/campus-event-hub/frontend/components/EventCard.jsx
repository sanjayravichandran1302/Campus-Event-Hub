import { Link } from 'react-router-dom';

function EventCard({ event }) {
  return (
    <div className="card event-card h-100">
      <div className="card-body d-flex flex-column">
        <div className="d-flex justify-content-between align-items-start mb-2">
          <span className="category-badge">{event.category}</span>
          <span className={`status-badge status-${(event.status || 'open').toLowerCase()}`}>
            {event.status}
          </span>
        </div>

        <h5 className="event-card-title">{event.title}</h5>
        <p className="event-card-desc text-muted mb-0">
          {event.description
            ? `${event.description.slice(0, 110)}${event.description.length > 110 ? '…' : ''}`
            : 'No description provided.'}
        </p>

        <ul className="event-meta">
          <li>📅 {event.date}</li>
          <li>⏰ {String(event.time).slice(0, 5)}</li>
          <li>📍 {event.venue}</li>
        </ul>

        <div className="mt-auto d-flex justify-content-between align-items-center">
          <span className="seats-left">🎟️ Capacity: {event.capacity}</span>
          <Link to={`/events/${event.id}`} className="btn ceh-btn btn-sm">View Details</Link>
        </div>
      </div>
    </div>
  );
}

export default EventCard;