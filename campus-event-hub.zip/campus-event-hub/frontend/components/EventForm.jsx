import { useState } from 'react';

const CATEGORIES = ['Technical', 'Cultural', 'Sports', 'Workshop', 'Seminar', 'Other'];
const STATUSES = ['OPEN', 'CLOSED', 'COMPLETED'];

function EventForm({ initialValues = {}, onSubmit, submitLabel = 'Save Event', onCancel }) {
  const [form, setForm] = useState({
    title: initialValues.title || '',
    description: initialValues.description || '',
    category: initialValues.category || 'Technical',
    date: initialValues.date || '',
    time: (initialValues.time || '').slice(0, 5),
    venue: initialValues.venue || '',
    organizer: initialValues.organizer || '',
    capacity: initialValues.capacity ?? 50,
    status: initialValues.status || 'OPEN',
  });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!form.title.trim() || !form.date || !form.time || !form.venue.trim() || !form.organizer.trim()) {
      setError('Please fill in all required fields marked with *.');
      return;
    }
    if (Number(form.capacity) < 1) {
      setError('Capacity must be at least 1.');
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit({ ...form, capacity: Number(form.capacity) });
    } catch (err) {
      setError(err?.response?.data?.message || 'Failed to save the event. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {error && <div className="alert alert-danger py-2">{error}</div>}

      <div className="row g-3">
        <div className="col-12">
          <label className="form-label small fw-semibold">Event Title *</label>
          <input name="title" className="form-control auth-input" placeholder="e.g. Annual Tech Fest 2025"
            value={form.title} onChange={handleChange} />
        </div>

        <div className="col-12">
          <label className="form-label small fw-semibold">Description</label>
          <textarea name="description" rows="4" className="form-control auth-input"
            placeholder="What is this event about?" value={form.description} onChange={handleChange} />
        </div>

        <div className="col-md-6">
          <label className="form-label small fw-semibold">Category *</label>
          <select name="category" className="form-select auth-input" value={form.category} onChange={handleChange}>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        <div className="col-md-6">
          <label className="form-label small fw-semibold">Status</label>
          <select name="status" className="form-select auth-input" value={form.status} onChange={handleChange}>
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        <div className="col-md-6">
          <label className="form-label small fw-semibold">Date *</label>
          <input type="date" name="date" className="form-control auth-input" value={form.date} onChange={handleChange} />
        </div>

        <div className="col-md-6">
          <label className="form-label small fw-semibold">Time *</label>
          <input type="time" name="time" className="form-control auth-input" value={form.time} onChange={handleChange} />
        </div>

        <div className="col-md-6">
          <label className="form-label small fw-semibold">Venue *</label>
          <input name="venue" className="form-control auth-input" placeholder="e.g. Main Auditorium"
            value={form.venue} onChange={handleChange} />
        </div>

        <div className="col-md-6">
          <label className="form-label small fw-semibold">Organizer *</label>
          <input name="organizer" className="form-control auth-input" placeholder="e.g. Department of CSE"
            value={form.organizer} onChange={handleChange} />
        </div>

        <div className="col-md-6">
          <label className="form-label small fw-semibold">Capacity *</label>
          <input type="number" name="capacity" min="1" className="form-control auth-input"
            value={form.capacity} onChange={handleChange} />
        </div>
      </div>

      <div className="d-flex gap-2 mt-4">
        <button type="submit" className="btn ceh-btn" disabled={submitting}>
          {submitting ? 'Saving…' : submitLabel}
        </button>
        {onCancel && (
          <button type="button" className="btn ceh-btn-outline" onClick={onCancel}>Cancel</button>
        )}
      </div>
    </form>
  );
}

export default EventForm;