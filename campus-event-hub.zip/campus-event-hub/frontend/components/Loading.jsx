function Loading({ message = 'Loading...' }) {
  return (
    <div className="loading-wrapper text-center py-5">
      <div className="spinner-border ceh-spinner" role="status">
        <span className="visually-hidden">Loading</span>
      </div>
      <p className="mt-3 text-muted mb-0">{message}</p>
    </div>
  );
}

export default Loading;