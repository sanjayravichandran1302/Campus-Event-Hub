import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="ceh-footer mt-auto">
      <div className="container">
        <div className="row gy-4">
          <div className="col-lg-4">
            <h5>🎓 Campus Event Hub</h5>
            <p className="small mb-0">
              One platform for every college event — discover, register, attend and earn
              certificates. Built with Spring Boot, React and MySQL.
            </p>
          </div>
          <div className="col-6 col-lg-2">
            <h6>Explore</h6>
            <ul className="list-unstyled small d-grid gap-2">
              <li><Link to="/">Home</Link></li>
              <li><Link to="/events">Events</Link></li>
              <li><Link to="/my-events">My Events</Link></li>
            </ul>
          </div>
          <div className="col-6 col-lg-3">
            <h6>Account</h6>
            <ul className="list-unstyled small d-grid gap-2">
              <li><Link to="/login">Login</Link></li>
              <li><Link to="/register">Register</Link></li>
              <li><Link to="/profile">Profile</Link></li>
              <li><Link to="/certificates">Certificates</Link></li>
            </ul>
          </div>
          <div className="col-lg-3">
            <h6>Roles</h6>
            <p className="small mb-0">
              👨‍🎓 Students register &amp; earn certificates.<br />
              🛠️ Admins manage events, attendance &amp; certificates.
            </p>
          </div>
        </div>
        <div className="footer-bottom d-flex flex-wrap justify-content-between gap-2">
          <span>© {new Date().getFullYear()} Campus Event Hub. All rights reserved.</span>
          <span>Made with ❤️ for college campuses</span>
        </div>
      </div>
    </footer>
  );
}

export default Footer;