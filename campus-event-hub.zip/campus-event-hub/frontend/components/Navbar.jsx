import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth';

const linkClass = ({ isActive }) => `nav-link-custom${isActive ? ' active' : ''}`;

function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  const handleLogout = () => {
    logout();
    closeMenu();
    navigate('/login');
  };

  return (
    <nav className="navbar navbar-expand-lg ceh-navbar sticky-top">
      <div className="container">
        <Link className="navbar-brand" to="/" onClick={closeMenu}>
          🎓 Campus<span className="text-primary-gradient">Event</span>Hub
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          aria-label="Toggle navigation"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <span className="navbar-toggler-icon" />
        </button>

        <div className={`collapse navbar-collapse${menuOpen ? ' show' : ''}`}>
          <ul className="navbar-nav ms-auto align-items-lg-center">
            <li className="nav-item"><NavLink className={linkClass} to="/" end onClick={closeMenu}>Home</NavLink></li>
            <li className="nav-item"><NavLink className={linkClass} to="/events" onClick={closeMenu}>Events</NavLink></li>

            {user?.role === 'STUDENT' && (
              <>
                <li className="nav-item"><NavLink className={linkClass} to="/my-events" onClick={closeMenu}>My Events</NavLink></li>
                <li className="nav-item"><NavLink className={linkClass} to="/certificates" onClick={closeMenu}>Certificates</NavLink></li>
              </>
            )}

            {user?.role === 'ADMIN' && (
              <li className="nav-item">
                <NavLink className={linkClass} to="/admin/attendance" onClick={closeMenu}>Scan Attendance</NavLink>
              </li>
            )}

            {user && (
              <li className="nav-item">
                <NavLink className={linkClass} to={user.role === 'ADMIN' ? '/admin' : '/dashboard'} onClick={closeMenu}>
                  Dashboard
                </NavLink>
              </li>
            )}

            {user ? (
              <>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/profile" onClick={closeMenu}>
                    👤 {user.name?.split(' ')[0]}
                    <span
                      className="badge ms-1"
                      style={{
                        fontSize: '0.68rem',
                        padding: '0.2rem 0.45rem',
                        backgroundColor: user.role === 'ADMIN' ? '#7c3aed' : '#2563eb',
                        verticalAlign: 'middle',
                      }}
                    >
                      {user.role}
                    </span>
                  </NavLink>
                </li>
                <li className="nav-item ms-lg-2 mt-2 mt-lg-0">
                  <button className="btn ceh-btn-danger btn-sm px-3" onClick={handleLogout}>Logout</button>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item mt-2 mt-lg-0">
                  <Link className="btn ceh-btn-outline btn-sm px-3 w-100" to="/login">Login</Link>
                </li>
                <li className="nav-item mt-2 mt-lg-0 ms-lg-2">
                  <Link className="btn ceh-btn btn-sm px-3 w-100" to="/register">Register</Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;