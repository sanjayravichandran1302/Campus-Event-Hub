import api from './api';

export async function getAllEvents(search = '', category = '') {
  const params = {};
  if (search && search.trim()) params.search = search.trim();
  if (category && category !== 'All') params.category = category;
  const res = await api.get('/events', { params });
  return res.data;
}

export async function getEventById(id) {
  const res = await api.get(`/events/${id}`);
  return res.data;
}

export async function createEvent(eventData) {
  const res = await api.post('/events', eventData);
  return res.data;
}

export async function updateEvent(id, eventData) {
  const res = await api.put(`/events/${id}`, eventData);
  return res.data;
}

export async function deleteEvent(id) {
  const res = await api.delete(`/events/${id}`);
  return res.data;
}