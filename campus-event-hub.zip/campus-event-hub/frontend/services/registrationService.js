import api from './api';

/* ---------- Event registration ---------- */
export async function registerForEvent(eventId) {
  const res = await api.post(`/registrations/event/${eventId}`);
  return res.data;
}

export async function getMyRegistrations() {
  const res = await api.get('/registrations/my');
  return res.data;
}

export async function getEventParticipants(eventId) {
  const res = await api.get(`/registrations/event/${eventId}`);
  return res.data;
}

export async function getAllRegistrations() {
  const res = await api.get('/registrations');
  return res.data;
}

/* ---------- QR attendance (Admin) ---------- */
export async function markAttendance(qrToken) {
  const res = await api.post('/attendance/mark', { qrToken });
  return res.data;
}

/* ---------- Certificates ---------- */
export async function generateCertificate(registrationId) {
  const res = await api.post(`/certificates/registration/${registrationId}`);
  return res.data;
}

export async function getMyCertificates() {
  const res = await api.get('/certificates/my');
  return res.data;
}

export async function getAllCertificates() {
  const res = await api.get('/certificates');
  return res.data;
}

export async function downloadCertificate(id) {
  const res = await api.get(`/certificates/${id}/download`, { responseType: 'blob' });
  return res.data;
}