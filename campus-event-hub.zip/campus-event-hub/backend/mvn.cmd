@echo off
set "JAVA_HOME=C:\Program Files\Java\jdk-27"
set "PATH=C:\Program Files\Java\jdk-27\bin;C:\Users\Sanjaykumar\apache-maven-3.9.6\bin;%PATH%"
"C:\Users\Sanjaykumar\apache-maven-3.9.6\bin\mvn.cmd" %*
