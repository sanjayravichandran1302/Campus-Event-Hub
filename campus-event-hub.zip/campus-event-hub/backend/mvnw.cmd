@echo off
set "JAVA_HOME=C:\Program Files\Java\jdk-27"
set "PATH=C:\Program Files\Java\jdk-27\bin;C:\Users\Sanjaykumar\apache-maven-3.9.6\bin;%PATH%"

if not "%~1"=="" (
    "C:\Users\Sanjaykumar\apache-maven-3.9.6\bin\mvn.cmd" %*
) else if not "%SPRING_PROFILE%"=="" (
    "C:\Users\Sanjaykumar\apache-maven-3.9.6\bin\mvn.cmd" spring-boot:run "-Dspring-boot.run.profiles=%SPRING_PROFILE%"
) else (
    "C:\Users\Sanjaykumar\apache-maven-3.9.6\bin\mvn.cmd" spring-boot:run
)
