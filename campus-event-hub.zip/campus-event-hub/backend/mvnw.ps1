# PowerShell Maven Wrapper script for campus-event-hub backend
$env:JAVA_HOME = "C:\Program Files\Java\jdk-27"
$env:PATH = "C:\Program Files\Java\jdk-27\bin;C:\Users\Sanjaykumar\apache-maven-3.9.6\bin;$env:PATH"
$mvnCmd = "C:\Users\Sanjaykumar\apache-maven-3.9.6\bin\mvn.cmd"

if ($args.Count -eq 0) {
    if ($env:SPRING_PROFILE) {
        $runArgs = @("spring-boot:run", "`"-Dspring-boot.run.profiles=$($env:SPRING_PROFILE)`"")
    } else {
        $runArgs = @("spring-boot:run")
    }
} else {
    # Recombine arguments that PowerShell improperly split around periods in -D flags
    $raw = @()
    for ($i = 0; $i -lt $args.Count; $i++) {
        $curr = $args[$i]
        if ($curr.StartsWith('.') -and $raw.Count -gt 0 -and $raw[-1].StartsWith('-D')) {
            $raw[-1] = $raw[-1] + $curr
        } else {
            $raw += $curr
        }
    }

    $runArgs = $raw | ForEach-Object {
        if ($_ -match '[\s=]' -and -not ($_ -match '^".*"$')) {
            "`"$_`""
        } else {
            $_
        }
    }
}

$fullCmd = "`"$mvnCmd`" " + ($runArgs -join " ")
cmd.exe /c $fullCmd
