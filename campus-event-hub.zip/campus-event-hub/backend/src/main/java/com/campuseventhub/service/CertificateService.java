package com.campuseventhub.service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.campuseventhub.entity.Certificate;
import com.campuseventhub.entity.Event;
import com.campuseventhub.entity.Registration;
import com.campuseventhub.entity.Role;
import com.campuseventhub.entity.User;
import com.campuseventhub.exception.BadRequestException;
import com.campuseventhub.exception.ForbiddenException;
import com.campuseventhub.exception.ResourceNotFoundException;
import com.campuseventhub.repository.CertificateRepository;
import com.campuseventhub.repository.RegistrationRepository;
import com.campuseventhub.repository.UserRepository;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

@Service
public class CertificateService {

    /** Used for certificate numbers like CEH-A1B2C3D4 (no confusing characters). */
    private static final String CERTIFICATE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final SecureRandom RANDOM = new SecureRandom();

    private final CertificateRepository certificateRepository;
    private final RegistrationRepository registrationRepository;
    private final UserRepository userRepository;

    public CertificateService(CertificateRepository certificateRepository,
                              RegistrationRepository registrationRepository,
                              UserRepository userRepository) {
        this.certificateRepository = certificateRepository;
        this.registrationRepository = registrationRepository;
        this.userRepository = userRepository;
    }

    /**
     * Generates a certificate for a registration. Rules:
     * 1) only admins or the owner of the registration may generate it,
     * 2) the student must have attended the event,
     * 3) only one certificate per user per event.
     */
    public Certificate generateCertificate(Long registrationId, String requesterEmail) {
        Registration registration = registrationRepository.findById(registrationId)
                .orElseThrow(() -> new ResourceNotFoundException("Registration not found with id: " + registrationId));

        User requester = userRepository.findByEmail(requesterEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        boolean isOwner = registration.getUser().getId().equals(requester.getId());
        if (!isOwner && requester.getRole() != Role.ADMIN) {
            throw new ForbiddenException("You are not authorized to generate this certificate");
        }
        if (!registration.isAttended()) {
            throw new BadRequestException("Certificate can only be issued after attendance is marked for the event");
        }
        if (certificateRepository.existsByUserIdAndEventId(registration.getUser().getId(), registration.getEvent().getId())) {
            throw new BadRequestException("A certificate has already been generated for this event");
        }

        Certificate certificate = new Certificate();
        certificate.setUser(registration.getUser());
        certificate.setEvent(registration.getEvent());
        certificate.setCertificateNumber(generateCertificateNumber());
        certificate.setIssuedDate(LocalDate.now());
        return certificateRepository.save(certificate);
    }

    private String generateCertificateNumber() {
        for (int attempt = 0; attempt < 20; attempt++) {
            StringBuilder builder = new StringBuilder("CEH-");
            for (int i = 0; i < 8; i++) {
                builder.append(CERTIFICATE_CHARS.charAt(RANDOM.nextInt(CERTIFICATE_CHARS.length())));
            }
            if (!certificateRepository.existsByCertificateNumber(builder.toString())) {
                return builder.toString();
            }
        }
        throw new IllegalStateException("Could not generate a unique certificate number");
    }

    public List<Certificate> getMyCertificates(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return certificateRepository.findByUserIdOrderByIssuedDateDesc(user.getId());
    }

    /** Used by the admin dashboard statistics. */
    public List<Certificate> getAllCertificates() {
        return certificateRepository.findAll(Sort.by(Sort.Direction.DESC, "issuedDate"));
    }

    /** Only the certificate owner (or an admin) may access a certificate. */
    public Certificate getCertificateForUser(Long certificateId, String email) {
        User requester = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Certificate certificate = certificateRepository.findById(certificateId)
                .orElseThrow(() -> new ResourceNotFoundException("Certificate not found with id: " + certificateId));

        boolean isOwner = certificate.getUser().getId().equals(requester.getId());
        if (!isOwner && requester.getRole() != Role.ADMIN) {
            throw new ForbiddenException("You can only access your own certificates");
        }
        return certificate;
    }

    /** Builds a downloadable A4 landscape certificate PDF with OpenPDF. */
    public byte[] buildCertificatePdf(Certificate certificate) {
        User user = certificate.getUser();
        Event event = certificate.getEvent();

        try {
            Document document = new Document(PageSize.A4.rotate(), 60, 60, 50, 50);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            PdfWriter writer = PdfWriter.getInstance(document, out);
            document.open();

            // Decorative border
            PdfContentByte canvas = writer.getDirectContent();
            canvas.setColorStroke(new Color(79, 70, 229));
            canvas.setLineWidth(3f);
            canvas.rectangle(30, 30, document.getPageSize().getWidth() - 60, document.getPageSize().getHeight() - 60);
            canvas.stroke();

            Font brandFont = new Font(Font.HELVETICA, 18, Font.BOLD, new Color(79, 70, 229));
            Font titleFont = new Font(Font.HELVETICA, 32, Font.BOLD, new Color(15, 23, 42));
            Font normalFont = new Font(Font.HELVETICA, 14, Font.NORMAL, new Color(71, 85, 105));
            Font nameFont = new Font(Font.HELVETICA, 26, Font.BOLD, new Color(79, 70, 229));
            Font smallFont = new Font(Font.HELVETICA, 11, Font.NORMAL, new Color(100, 116, 139));

            document.add(centered("CAMPUS EVENT HUB", brandFont, 0));
            document.add(centered("CERTIFICATE OF PARTICIPATION", titleFont, 20));
            document.add(centered("This certificate is proudly presented to", normalFont, 35));
            document.add(centered(user.getName(), nameFont, 8));
            document.add(centered("for actively participating in", normalFont, 12));
            document.add(centered(event.getTitle(), nameFont, 8));
            document.add(centered("held on " + event.getDate() + " at " + event.getVenue(), normalFont, 12));
            document.add(centered("Certificate Number: " + certificate.getCertificateNumber()
                    + "    |    Issued on: " + certificate.getIssuedDate(), smallFont, 30));

            // Signature area
            PdfPTable signTable = new PdfPTable(2);
            signTable.setWidthPercentage(60);
            signTable.setSpacingBefore(45);
            signTable.addCell(noBorderCell("_______________________", smallFont));
            signTable.addCell(noBorderCell("_______________________", smallFont));
            signTable.addCell(noBorderCell("Event Coordinator", smallFont));
            signTable.addCell(noBorderCell("Principal", smallFont));
            document.add(signTable);

            document.close();
            return out.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate certificate PDF", e);
        }
    }

    private Paragraph centered(String text, Font font, int spacingBefore) {
        Paragraph paragraph = new Paragraph(text, font);
        paragraph.setAlignment(Element.ALIGN_CENTER);
        paragraph.setSpacingBefore(spacingBefore);
        return paragraph;
    }

    private PdfPCell noBorderCell(String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPaddingTop(6);
        return cell;
    }
}