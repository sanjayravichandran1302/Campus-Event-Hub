package com.campuseventhub.service;

import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.campuseventhub.dto.AuthResponse;
import com.campuseventhub.dto.LoginRequest;
import com.campuseventhub.dto.RegisterRequest;
import com.campuseventhub.entity.Role;
import com.campuseventhub.entity.User;
import com.campuseventhub.exception.BadRequestException;
import com.campuseventhub.exception.ResourceNotFoundException;
import com.campuseventhub.repository.UserRepository;
import com.campuseventhub.security.JwtService;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       JwtService jwtService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public static final java.util.Set<String> ADMIN_EMAILS = java.util.Set.of(
        "sanjayravichandran1302@gmail.com",
        "ishwaryayogaraj557@gmail.com"
    );

    /** Creates a new account. Only pre-authorized emails receive ADMIN role; all others become STUDENT. */
    public AuthResponse register(RegisterRequest request) {
        String email = request.getEmail().trim().toLowerCase();

        if (userRepository.existsByEmail(email)) {
            throw new BadRequestException("An account with this email already exists");
        }

        User user = new User();
        user.setName(request.getName().trim());
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(request.getPassword())); // BCrypt hash
        user.setRole(ADMIN_EMAILS.contains(email) ? Role.ADMIN : Role.STUDENT);
        user.setDepartment(request.getDepartment() == null ? null : request.getDepartment().trim());
        user.setCreatedAt(LocalDateTime.now());

        try {
            userRepository.save(user);
        } catch (DataIntegrityViolationException e) {
            throw new BadRequestException("An account with this email already exists");
        }

        return buildResponse(user);
    }

    public AuthResponse login(LoginRequest request) {
        String email = request.getEmail().trim().toLowerCase();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new BadRequestException("Invalid email or password"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BadRequestException("Invalid email or password");
        }

        if (ADMIN_EMAILS.contains(email) && user.getRole() != Role.ADMIN) {
            user.setRole(Role.ADMIN);
            user = userRepository.save(user);
        }

        return buildResponse(user);
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }

    public User updateProfile(String email, Map<String, String> request) {
        User user = getUserByEmail(email);

        if (request.containsKey("name") && request.get("name") != null && !request.get("name").isBlank()) {
            user.setName(request.get("name").trim());
        }
        if (request.containsKey("department") && request.get("department") != null) {
            user.setDepartment(request.get("department").trim());
        }

        return userRepository.save(user);
    }

    private AuthResponse buildResponse(User user) {
        String token = jwtService.generateToken(user.getEmail(), user.getRole().name());
        return new AuthResponse(token, user.getName(), user.getEmail(), user.getRole().name());
    }
}