package com.campuseventhub.entity;

public enum Role {
    STUDENT,
    ADMIN
}