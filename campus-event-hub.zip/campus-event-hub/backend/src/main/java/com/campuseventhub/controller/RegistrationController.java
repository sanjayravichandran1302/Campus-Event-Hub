package com.campuseventhub.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.campuseventhub.entity.Registration;
import com.campuseventhub.service.RegistrationService;

@RestController
@RequestMapping("/api/registrations")
public class RegistrationController {

    private final RegistrationService registrationService;

    public RegistrationController(RegistrationService registrationService) {
        this.registrationService = registrationService;
    }

    /** STUDENT – register for an event and receive a unique QR token. */
    @PostMapping("/event/{eventId}")
    public ResponseEntity<Registration> registerForEvent(@PathVariable Long eventId,
                                                         @AuthenticationPrincipal UserDetails userDetails) {
        Registration registration = registrationService.registerForEvent(eventId, userDetails.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED).body(registration);
    }

    /** STUDENT – my registrations. */
    @GetMapping("/my")
    public ResponseEntity<List<Registration>> getMyRegistrations(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(registrationService.getMyRegistrations(userDetails.getUsername()));
    }

    /** ADMIN – all registrations (dashboard statistics). */
    @GetMapping
    public ResponseEntity<List<Registration>> getAllRegistrations() {
        return ResponseEntity.ok(registrationService.getAllRegistrations());
    }

    /** ADMIN – participants of a specific event. */
    @GetMapping("/event/{eventId}")
    public ResponseEntity<List<Registration>> getEventParticipants(@PathVariable Long eventId) {
        return ResponseEntity.ok(registrationService.getEventParticipants(eventId));
    }
}