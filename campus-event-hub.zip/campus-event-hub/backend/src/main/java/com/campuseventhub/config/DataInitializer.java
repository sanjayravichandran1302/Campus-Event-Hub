package com.campuseventhub.config;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.campuseventhub.entity.Event;
import com.campuseventhub.entity.Role;
import com.campuseventhub.entity.User;
import com.campuseventhub.repository.CertificateRepository;
import com.campuseventhub.repository.EventRepository;
import com.campuseventhub.repository.RegistrationRepository;
import com.campuseventhub.repository.UserRepository;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    // List of previously pre-seeded mock events to remove so only admin events remain
    private static final List<String> MOCK_EVENT_TITLES = List.of(
        "National Level Hackathon 2026",
        "TechSprint: Full-Stack & Generative AI Workshop",
        "Rhythm '26 - Annual Cultural Extravaganza",
        "Inter-Department Cricket Championship",
        "CyberShield: Ethical Hacking & CTF Challenge"
    );

    private final UserRepository userRepository;
    private final EventRepository eventRepository;
    private final RegistrationRepository registrationRepository;
    private final CertificateRepository certificateRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository,
                           EventRepository eventRepository,
                           RegistrationRepository registrationRepository,
                           CertificateRepository certificateRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.eventRepository = eventRepository;
        this.registrationRepository = registrationRepository;
        this.certificateRepository = certificateRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        // Ensure authorized administrators exist for admin event creation & management
        ensureUser("Sanjay Kumar", "sanjayravichandran1302@gmail.com", "admin123", Role.ADMIN, "Administration");
        ensureUser("Ishwarya Yogaraj", "ishwaryayogaraj557@gmail.com", "admin123", Role.ADMIN, "Administration");

        // Ensure default student user exists
        ensureUser("Mohammed Asif", "mohammedasifm12@gmail.com", "student123", Role.STUDENT, "Computer Science");

        // Clean up any legacy mock events so the system stores only events created by admins
        purgeMockEvents();
    }

    private void ensureUser(String name, String email, String defaultPassword, Role role, String dept) {
        userRepository.findByEmail(email).ifPresentOrElse(
            user -> {
                if (user.getRole() != role) {
                    user.setRole(role);
                    userRepository.save(user);
                    log.info("Updated {} to role {}", email, role);
                }
            },
            () -> {
                User user = new User();
                user.setName(name);
                user.setEmail(email);
                user.setPassword(passwordEncoder.encode(defaultPassword));
                user.setRole(role);
                user.setDepartment(dept);
                userRepository.save(user);
                log.info("Initialized {} account: {}", role, email);
            }
        );
    }

    private void purgeMockEvents() {
        for (String title : MOCK_EVENT_TITLES) {
            List<Event> mockEvents = eventRepository.findByTitleContainingIgnoreCase(title);
            for (Event event : mockEvents) {
                certificateRepository.deleteByEventId(event.getId());
                registrationRepository.deleteByEventId(event.getId());
                eventRepository.delete(event);
                log.info("Removed legacy mock event: '{}' (id: {})", event.getTitle(), event.getId());
            }
        }
    }
}
