package com.campuseventhub.repository;

import com.campuseventhub.entity.Event;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EventRepository extends JpaRepository<Event, Long> {

    List<Event> findByTitleContainingIgnoreCase(String title);

    List<Event> findByCategoryIgnoreCase(String category);

    List<Event> findByTitleContainingIgnoreCaseOrCategoryContainingIgnoreCase(String title, String category);
}