package com.campuseventhub.controller;

import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.campuseventhub.entity.Certificate;
import com.campuseventhub.service.CertificateService;

@RestController
@RequestMapping("/api/certificates")
public class CertificateController {

    private final CertificateService certificateService;

    public CertificateController(CertificateService certificateService) {
        this.certificateService = certificateService;
    }

    /** STUDENT/ADMIN – all certificates (dashboard statistics). */
    @GetMapping
    public ResponseEntity<List<Certificate>> getAllCertificates() {
        return ResponseEntity.ok(certificateService.getAllCertificates());
    }

    /** STUDENT – my certificates. */
    @GetMapping("/my")
    public ResponseEntity<List<Certificate>> getMyCertificates(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(certificateService.getMyCertificates(userDetails.getUsername()));
    }

    /** STUDENT (own) / ADMIN – generate a certificate for a registration. */
    @PostMapping("/registration/{registrationId}")
    public ResponseEntity<Certificate> generateCertificate(
            @PathVariable Long registrationId,
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(certificateService.generateCertificate(registrationId, userDetails.getUsername()));
    }

    /** STUDENT (own) / ADMIN – download the certificate as a PDF. */
    @GetMapping("/{id}/download")
    public ResponseEntity<byte[]> downloadCertificate(@PathVariable Long id,
                                                      @AuthenticationPrincipal UserDetails userDetails) {
        Certificate certificate = certificateService.getCertificateForUser(id, userDetails.getUsername());
        byte[] pdf = certificateService.buildCertificatePdf(certificate);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"Certificate-" + certificate.getCertificateNumber() + ".pdf\"")
                .body(pdf);
    }
}