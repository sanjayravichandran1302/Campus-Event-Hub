package com.campuseventhub.service;

import org.springframework.stereotype.Service;

import com.campuseventhub.entity.Registration;
import com.campuseventhub.exception.BadRequestException;
import com.campuseventhub.repository.RegistrationRepository;

@Service
public class AttendanceService {

    private final RegistrationRepository registrationRepository;

    public AttendanceService(RegistrationRepository registrationRepository) {
        this.registrationRepository = registrationRepository;
    }

    /**
     * Marks attendance for a scanned/entered QR token after validating:
     * 1) a registration exists for the token, 2) attendance is not duplicated.
     */
    public Registration markAttendance(String qrToken) {
        if (qrToken == null || qrToken.isBlank()) {
            throw new BadRequestException("QR token is required");
        }

        Registration registration = registrationRepository.findByQrToken(qrToken.trim())
                .orElseThrow(() -> new BadRequestException("Invalid QR token. No registration found for this token."));

        if (registration.isAttended()) {
            throw new BadRequestException("Attendance has already been marked for " + registration.getUser().getName());
        }

        registration.setAttended(true);
        return registrationRepository.save(registration);
    }
}