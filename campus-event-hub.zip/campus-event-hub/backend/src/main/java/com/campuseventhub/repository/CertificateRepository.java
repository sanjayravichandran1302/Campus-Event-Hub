package com.campuseventhub.repository;

import com.campuseventhub.entity.Certificate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface CertificateRepository extends JpaRepository<Certificate, Long> {

    List<Certificate> findByUserIdOrderByIssuedDateDesc(Long userId);

    List<Certificate> findByEventId(Long eventId);

    boolean existsByUserIdAndEventId(Long userId, Long eventId);

    boolean existsByCertificateNumber(String certificateNumber);

    @Modifying
    @Transactional
    void deleteByEventId(Long eventId);
}