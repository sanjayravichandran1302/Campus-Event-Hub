package com.campuseventhub.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.campuseventhub.entity.Event;
import com.campuseventhub.entity.Registration;
import com.campuseventhub.entity.User;
import com.campuseventhub.exception.BadRequestException;
import com.campuseventhub.exception.ResourceNotFoundException;
import com.campuseventhub.repository.EventRepository;
import com.campuseventhub.repository.RegistrationRepository;
import com.campuseventhub.repository.UserRepository;

@Service
public class RegistrationService {

    private final RegistrationRepository registrationRepository;
    private final EventRepository eventRepository;
    private final UserRepository userRepository;

    public RegistrationService(RegistrationRepository registrationRepository,
                               EventRepository eventRepository,
                               UserRepository userRepository) {
        this.registrationRepository = registrationRepository;
        this.eventRepository = eventRepository;
        this.userRepository = userRepository;
    }

    /**
     * Registers a student for an event after validating:
     * 1) the event exists, 2) the event is OPEN,
     * 3) the student is not already registered, 4) capacity is not full.
     */
    public Registration registerForEvent(Long eventId, String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with id: " + eventId));

        if (!Event.STATUS_OPEN.equalsIgnoreCase(event.getStatus())) {
            throw new BadRequestException("Registrations are " + event.getStatus() + " for this event");
        }
        if (registrationRepository.existsByUserIdAndEventId(user.getId(), event.getId())) {
            throw new BadRequestException("You have already registered for this event");
        }
        if (registrationRepository.countByEventId(event.getId()) >= event.getCapacity()) {
            throw new BadRequestException("Event capacity is full");
        }

        Registration registration = new Registration();
        registration.setUser(user);
        registration.setEvent(event);
        registration.setRegisteredAt(LocalDateTime.now());
        registration.setAttended(false);
        registration.setQrToken(UUID.randomUUID().toString().replace("-", "").toUpperCase());

        return registrationRepository.save(registration);
    }

    public List<Registration> getMyRegistrations(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return registrationRepository.findByUserIdOrderByRegisteredAtDesc(user.getId());
    }

    public List<Registration> getEventParticipants(Long eventId) {
        if (!eventRepository.existsById(eventId)) {
            throw new ResourceNotFoundException("Event not found with id: " + eventId);
        }
        return registrationRepository.findByEventId(eventId);
    }

    /** Used by the admin dashboard statistics. */
    public List<Registration> getAllRegistrations() {
        return registrationRepository.findAll(Sort.by(Sort.Direction.DESC, "registeredAt"));
    }
}