package com.campuseventhub.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.campuseventhub.entity.Registration;
import com.campuseventhub.service.AttendanceService;

@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;

    public AttendanceController(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    /** ADMIN – mark attendance using the QR token. Body: { "qrToken": "..." } */
    @PostMapping("/mark")
    public ResponseEntity<Map<String, Object>> markAttendance(@RequestBody Map<String, String> request) {
        Registration registration = attendanceService.markAttendance(request.get("qrToken"));

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Attendance marked successfully for "
                + registration.getUser().getName() + " (" + registration.getEvent().getTitle() + ")");
        response.put("registration", registration);
        return ResponseEntity.ok(response);
    }
}