package com.campuseventhub.service;

import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.campuseventhub.dto.EventRequest;
import com.campuseventhub.entity.Event;
import com.campuseventhub.exception.BadRequestException;
import com.campuseventhub.exception.ResourceNotFoundException;
import com.campuseventhub.repository.CertificateRepository;
import com.campuseventhub.repository.EventRepository;
import com.campuseventhub.repository.RegistrationRepository;

@Service
public class EventService {

    private final EventRepository eventRepository;
    private final RegistrationRepository registrationRepository;
    private final CertificateRepository certificateRepository;

    public EventService(EventRepository eventRepository,
                        RegistrationRepository registrationRepository,
                        CertificateRepository certificateRepository) {
        this.eventRepository = eventRepository;
        this.registrationRepository = registrationRepository;
        this.certificateRepository = certificateRepository;
    }

    /** Returns all events, optionally filtered by a search term and/or category. */
    public List<Event> getAllEvents(String search, String category) {
        boolean hasSearch = search != null && !search.isBlank();
        boolean hasCategory = category != null && !category.isBlank() && !"all".equalsIgnoreCase(category);

        List<Event> events;
        if (hasSearch && hasCategory) {
            events = eventRepository
                    .findByTitleContainingIgnoreCaseOrCategoryContainingIgnoreCase(search.trim(), search.trim())
                    .stream()
                    .filter(event -> event.getCategory().equalsIgnoreCase(category))
                    .toList();
        } else if (hasSearch) {
            events = eventRepository.findByTitleContainingIgnoreCase(search.trim());
        } else if (hasCategory) {
            events = eventRepository.findByCategoryIgnoreCase(category.trim());
        } else {
            events = eventRepository.findAll();
        }

        return events.stream()
                .sorted(Comparator.comparing(Event::getDate).thenComparing(Event::getTime))
                .toList();
    }

    public Event getEventById(Long id) {
        return eventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found with id: " + id));
    }

    public Event createEvent(EventRequest request) {
        Event event = new Event();
        applyRequest(event, request);
        return eventRepository.save(event);
    }

    public Event updateEvent(Long id, EventRequest request) {
        Event event = getEventById(id);
        applyRequest(event, request);
        return eventRepository.save(event);
    }

    @Transactional
    public void deleteEvent(Long id) {
        Event event = getEventById(id);
        certificateRepository.deleteByEventId(id);
        registrationRepository.deleteByEventId(id);
        eventRepository.delete(event);
    }

    private void applyRequest(Event event, EventRequest request) {
        event.setTitle(request.getTitle().trim());
        event.setDescription(request.getDescription() == null ? null : request.getDescription().trim());
        event.setCategory(request.getCategory().trim());
        event.setDate(request.getDate());
        event.setTime(request.getTime());
        event.setVenue(request.getVenue().trim());
        event.setOrganizer(request.getOrganizer().trim());
        event.setCapacity(request.getCapacity());
        event.setStatus(normalizeStatus(request.getStatus()));
    }

    private String normalizeStatus(String status) {
        if (status == null || status.isBlank()) {
            return Event.STATUS_OPEN;
        }
        String upper = status.trim().toUpperCase();
        if (!upper.equals(Event.STATUS_OPEN)
                && !upper.equals(Event.STATUS_CLOSED)
                && !upper.equals(Event.STATUS_COMPLETED)) {
            throw new BadRequestException("Invalid status. Allowed values are OPEN, CLOSED and COMPLETED.");
        }
        return upper;
    }
}