# Start MySQL Service and Verify
# Run this from Administrator PowerShell

Write-Host "=== Starting MySQL80 Service ===" -ForegroundColor Cyan

try {
    Start-Service MySQL80 -ErrorAction Stop
    Start-Sleep -Seconds 2
    $svc = Get-Service MySQL80
    if ($svc.Status -eq 'Running') {
        Write-Host "`nSUCCESS: MySQL80 is RUNNING!" -ForegroundColor Green
        Test-NetConnection -ComputerName 127.0.0.1 -Port 3306
    } else {
        Write-Host "`nStatus: $($svc.Status)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "`nError starting MySQL80: $_" -ForegroundColor Red
}
